﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Traffic_System
{
    public partial class Display : Form
    {
        User_Info user = new User_Info();
        public Display()
        {
           
            InitializeComponent();
            DisplayMsg(user);
        }

        public void DisplayMsg(User_Info user)
        {
            lname.Text = user.Lname;
            lblFname.Text = user.Fname;
            lblAge.Text =Convert.ToString(user.Age);
            lblgender.Text = user.gender;
            vicNum.Text = user.Vechile;
            lbllic.Text = Convert.ToString(user.Licen);
            lblStat.Text = Convert.ToString(user.stat);
            lblIssue.Text = Convert.ToString(user.issue);
            lbldeads.Text = Convert.ToString(user.dead);
            lblcode.Text = user.offen;
             lbltic.Text = Convert.ToString(user.tick);
             lblsum.Text = Summonds();
             lblpay.Text  = payed();
        }

        String Summonds()
        {
            int result = DateTime.Compare(user.issue, user.dead);


            if (result < 0)
            {
                user.summon = true;
                user.stat = true;
                return "get Summond";
            }
            else
                if (result == 0)
                {
                    user.summon = true;
                    user.stat = true;
                    return "get Summond";
                }
                else
                {
                    user.summon = false;
                    user.stat = false;
                    return "no Summond";
                }
        }

        String payed()
        {
            int result = DateTime.Compare(user.issue, user.dead);


            if (result < 0)
            {
                user.stat = true;
                return "dnt pay";
            }
            else
                if (result == 0)
                {
                    user.stat = true;
                    return "dnt pay";
                }
                else
                {
                    user.stat = false;
                    return "paid";
                }
        }
    }
}
