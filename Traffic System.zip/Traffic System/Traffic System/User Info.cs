﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Traffic_System
{
   public class User_Info
    {
       public String Lname { set; get; }
       public String Fname { set; get; }
       public int Age { set; get; }
       public int Licen { set; get; }
       public int tick { set; get; }
       public String gender { set; get; }
       public DateTime issue { set; get; }
       public DateTime dead { set; get; }
       public Boolean stat { set; get; }
       public Boolean summon { set; get; }
       public double paid { set; get; }
       public String offen { set; get; }
       public String ispayed { set; get; }
       public String ticno { set; get; }
       public String isSummond { set; get; }

       public String Vechile { set; get; }
    }
}
