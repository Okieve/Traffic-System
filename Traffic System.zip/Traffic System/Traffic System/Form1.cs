﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Traffic_System
{
    public partial class Form1 : Form
    {
        User_Info user = new User_Info();
        Display dis = new Display();
        public Form1()
        {
            InitializeComponent();
        }

        private void btnsub_Click(object sender, EventArgs e)
        {
            user.Lname = tbLname.Text;
            user.Fname = tbfname.Text;
            user.Age = Convert.ToInt16(ndage.Value.ToString());
            user.Licen = Convert.ToInt16(licNum.Text);
            user.ticno = numTic.Value.ToString();
            user.tick = Convert.ToInt16(tickNum.Text);
            user.paid = Convert.ToInt16(tbpay.Text);
            user.issue = Convert.ToDateTime(issuedate.Text);
            user.dead = Convert.ToDateTime(deadlines.Text);
            user.gender = checkGender();
            user.offen = checkOffense();
            user.Vechile=vehNum.Text;
            dis.Show();
            dis.DisplayMsg(user);
            this.Visible = false;

        }

        private void btncl_Click(object sender, EventArgs e)
        {
           
            
        }

        String checkGender()
        {
            if(male.Checked==true)
            {
                 return user.gender = "male";
            }
                  if(female.Checked==true)
            {
                return user.gender = "female";
            }
            else
            {
                MessageBox.Show("You dnt select any gender");
            }
                  return user.gender;
        }

        String checkOffense()
        {
            if (RBD.Checked == true)
            {
                return user.offen = "DR3";
            }
            if (RBF.Checked == true)
            {
                return user.offen = "FA3";
            }
            else
            {
                MessageBox.Show("You dnt select any Offense");
            }
            return user.offen;
        }
    
      
    }
}
